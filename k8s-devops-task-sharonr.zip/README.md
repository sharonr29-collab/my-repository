
# DevOps Assessment Task Documentation

## Author
- Maintained by: sharonr

## Prerequisites
1. AWS account with IAM permissions for EKS.
2. Terraform CLI installed.
3. kubectl and AWS CLI configured.
4. Docker installed for building the Docker image.

## Steps to Deploy

### 1. Provision Cloud Infrastructure
- Navigate to the terraform directory and run:
    terraform init
    terraform apply -auto-approve

### 2. Build Docker Image
- Navigate to the Dockerfile directory:
    docker build -t static-web-app .

### 3. Push Docker Image to Container Registry
- Tag and push to a Docker registry (e.g., Docker Hub):
    docker tag static-web-app sharonr/static-web-app:latest
    docker push sharonr/static-web-app:latest

### 4. Deploy Kubernetes Resources
- Apply Kubernetes Deployment and Service:
    kubectl apply -f k8s-deployment.yaml

### 5. Set Up Monitoring
- Deploy Prometheus using Helm:
    helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
    helm install prometheus prometheus-community/prometheus

### 6. Access the Application
- Get the LoadBalancer URL:
    kubectl get svc static-web-service

- Access using the LoadBalancer URL in your browser.

### Clean-Up
- Destroy all resources using Terraform:
    terraform destroy -auto-approve
